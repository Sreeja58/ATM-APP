const firebaseConfig = {
    //   copy your firebase config informations
    apiKey: "AIzaSyCEg3c2I4E4Ricc4oswdfHkHdqPhZklQqw",
    authDomain: "atm-app-9b3d3.firebaseapp.com",
    databaseURL: "https://atm-app-9b3d3-default-rtdb.firebaseio.com",
    projectId: "atm-app-9b3d3",
    storageBucket: "atm-app-9b3d3.appspot.com",
    messagingSenderId: "1087173322595",
    appId: "1:1087173322595:web:8f8d7d0784114551cfd556",
    measurementId: "G-416P8ZT4Q1"
  };
  
  // initialize firebase
  firebase.initializeApp(firebaseConfig);
  
  // reference your database
  var contactFormDB = firebase.database().ref("contactForm");
  
  document.getElementById("contactForm").addEventListener("submit", submitForm);
  
  function submitForm(e) {
    e.preventDefault();
  
    var formData = {
        firstname: getElementVal("firstname"),
        middlename: getElementVal("middlename"),
        lastname: getElementVal("lastname"),
        countrycode: getElementVal("countrycode"),
        mobilenumber: getElementVal("mobilenumber"),
        email: getElementVal("email"),
        password: getElementVal("password"),
        passwordrepeat: getElementVal("passwordrepeat"),
        pin: getElementVal("pin")
      };
    saveMessages(formData);
  
    //   enable alert
    document.querySelector(".alert").style.display = "block";
  
    //   remove the alert
    setTimeout(() => {
      document.querySelector(".alert").style.display = "none";
    }, 3000);
  
    //   reset the form
    document.getElementById("contactForm").reset();
  }
  
  const saveMessages = (formData) => {
    var newContactForm = contactFormDB.push();
  
    newContactForm.set(formData);
  };
  
  const getElementVal = (id) => {
    return document.getElementById(id).value;
  };