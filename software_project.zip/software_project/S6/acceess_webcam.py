import cv2
import face_recognition

# Connect to the default camera
video_capture = cv2.VideoCapture(0)

# Flag variable to check if the photo is taken
photo_taken = False

# Loop over frames from the camera
while True:
    # Capture a frame
    ret, frame = video_capture.read()

    # Find faces in the frame
    face_locations = face_recognition.face_locations(frame)

    # Iterate over each face and add it to the database
    for face_location in face_locations:
        # Extract the coordinates of the face
        top, right, bottom, left = face_location

        # Extract the face from the frame
        face_image = frame[top:bottom, left:right]

        # Add the face to the database
        # You can use a database library like SQLite or MySQL for this
        # For example, you could store the face as a blob in a table

    # Display the resulting image with the face locations
    for face_location in face_locations:
        top, right, bottom, left = face_location
        cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
    cv2.imshow('Video', frame)

    # Specify the folder to store the images
    output_folder = "/home/emeric/Desktop/S6/images_for_login/"

    # Capture a photo after detecting a face
    if len(face_locations) > 0 and not photo_taken:
        # Capture the first detected face
        top, right, bottom, left = face_locations[0]
        face_image = frame[top:bottom, left:right]

        # Generate a unique filename for the captured image
        image_filename = output_folder + "detected_face.jpg"

        # Save the face image to the specified folder
        cv2.imwrite(image_filename, face_image)
        print("Face photo captured:", image_filename)

        # Set the flag to True to indicate photo taken
        photo_taken = True

    # Exit if the photo is taken
    if photo_taken:
        break

    # Exit if the user presses 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the camera and close the window
video_capture.release()
cv2.destroyAllWindows()
